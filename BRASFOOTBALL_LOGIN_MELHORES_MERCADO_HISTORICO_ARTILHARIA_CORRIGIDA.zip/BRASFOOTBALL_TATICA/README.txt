BRASFOOTBALL — JOGO COMPLETO
================================

Como iniciar:
1. Extraia este arquivo ZIP.
2. Abra a pasta BRASFOOTBALL.
3. Abra o arquivo index.html no navegador.

Tecnologias:
- HTML
- CSS
- JavaScript

O projeto inclui:
- Tela inicial
- Menu principal
- Clube
- Elenco
- Mercado
- Campeonato
- Jogos
- Simulação de partidas
- Classificação
- Artilharia
- Estatísticas
- Finanças
- Configurações
- Salvamento da carreira no navegador


NOVO: tela tactica.html com formações, mentalidade, pressão, ritmo, marcação, largura, linha defensiva e bolas paradas. A tática salva no localStorage e influencia a simulação da partida.
