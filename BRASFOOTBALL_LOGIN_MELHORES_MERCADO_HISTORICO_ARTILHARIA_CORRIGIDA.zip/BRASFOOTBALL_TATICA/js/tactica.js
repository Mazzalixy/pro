 
const FORMATIONS = {
 "4-3-3":[
  ["GOL",50,92],["LAT",18,72],["ZAG",38,78],["ZAG",62,78],["LAT",82,72],
  ["MEI",30,53],["VOL",50,58],["MEI",70,53],["ATA",20,25],["ATA",50,18],["ATA",80,25]
 ],
 "4-4-2":[
  ["GOL",50,92],["LAT",18,72],["ZAG",38,78],["ZAG",62,78],["LAT",82,72],
  ["MEI",20,55],["MEI",42,50],["MEI",58,50],["MEI",80,55],
  ["ATA",38,23],["ATA",62,23]
 ],
 "4-2-3-1":[
  ["GOL",50,92],["LAT",18,72],["ZAG",38,78],["ZAG",62,78],["LAT",82,72],
  ["VOL",35,58],["VOL",65,58],["MEI",22,39],["MEI",50,35],["MEI",78,39],["ATA",50,18]
 ],
 "3-5-2":[
  ["GOL",50,92],["ZAG",30,76],["ZAG",50,80],["ZAG",70,76],
  ["LAT",14,54],["MEI",34,55],["VOL",50,60],["MEI",66,55],["LAT",86,54],
  ["ATA",40,23],["ATA",60,23]
 ],
 "3-4-3":[
  ["GOL",50,92],["ZAG",30,77],["ZAG",50,81],["ZAG",70,77],
  ["MEI",20,55],["MEI",40,53],["MEI",60,53],["MEI",80,55],
  ["ATA",22,25],["ATA",50,18],["ATA",78,25]
 ],
 "5-3-2":[
  ["GOL",50,92],["LAT",12,70],["ZAG",31,77],["ZAG",50,80],["ZAG",69,77],["LAT",88,70],
  ["MEI",31,54],["VOL",50,58],["MEI",69,54],["ATA",40,23],["ATA",60,23]
 ]
};

function tacticState(s){
  if(!s.tactic) s.tactic={formation:"4-3-3",mentality:"Equilibrada",pressing:"Médio",tempo:"Normal",marking:"Zona",width:"Normal",defensiveLine:"Normal",setPieces:"Equilibrado"};
  return s.tactic;
}
function renderBoard(s){
  const board=document.getElementById("playersBoard");
  const formation=tacticState(s).formation;
  const players=(s.tacticalXI||s.squad.slice(0,11)).map(id=>s.squad.find(p=>p.id===id)).filter(Boolean);
  const spots=FORMATIONS[formation]||FORMATIONS["4-3-3"];
  board.innerHTML=spots.map((sp,i)=>{
    const p=players[i];
    return `<div class="tactic-player" style="left:${sp[1]}%;top:${sp[2]}%">
      <div class="token">${p?.position||sp[0]}</div><small>${p?.name||"Jogador"}</small>
    </div>`;
  }).join("");
}
function calcTacticScore(t){
  const mental={Defensiva:72,Equilibrada:80,Ofensiva:88}[t.mentality]||80;
  const press={Baixo:72,Médio:80,Alto:88}[t.pressing]||80;
  const tempo={Lento:74,Normal:80,Rápido:87}[t.tempo]||80;
  return Math.round((mental+press+tempo)/3);
}
document.addEventListener("DOMContentLoaded",()=>{
 const s=loadGame();if(!s)return;renderShell("Tática");tacticState(s);
 const c=document.getElementById("pageContent"),t=s.tactic;
 c.innerHTML=`
 <div class="page-head"><div><p class="eyebrow">CENTRAL TÁTICA</p><h1>Tática e formação 🎯</h1><p>Monte sua equipe e defina como o clube vai jogar.</p></div>
 <button id="saveTactic" class="btn primary">💾 Salvar tática</button></div>
 <div class="tactic-layout">
  <section class="tactic-card">
   <div class="panel-title"><div><h2>Campo</h2><p>Formação atual: <b id="formationName">${t.formation}</b></p></div><span class="badge green">PRÉ-JOGO</span></div>
   <div class="tactic-board" style="margin-top:15px"><div class="field-line"></div><div class="penalty top"></div><div class="penalty bottom"></div><div id="playersBoard" class="players-board"></div></div>
  </section>
  <section class="tactic-controls">
   <div class="tactic-card"><h2>Formação</h2><p class="muted">Escolha a disposição dos 11 titulares e altere quem começa.</p>
    <div class="formation-grid">${Object.keys(FORMATIONS).map(f=>`<button class="formation-btn ${t.formation===f?"active":""}" data-formation="${f}">${f}</button>`).join("")}</div>
    <div class="starter-actions"><button id="bestXI" class="btn secondary">⭐ Selecionar melhores</button><span class="muted">Monta automaticamente os 11 melhores para a formação.</span></div><div class="starter-list" id="starterList"></div>
   </div>
   <div class="tactic-card"><h2>Estilo de jogo</h2><p class="muted">Essas opções influenciam a simulação das partidas.</p>
    <div class="tactic-grid">
     <div class="tactic-field"><label>Mentalidade</label><select id="mentality"><option>Defensiva</option><option>Equilibrada</option><option>Ofensiva</option></select></div>
     <div class="tactic-field"><label>Pressão</label><select id="pressing"><option>Baixo</option><option>Médio</option><option>Alto</option></select></div>
     <div class="tactic-field"><label>Ritmo</label><select id="tempo"><option>Lento</option><option>Normal</option><option>Rápido</option></select></div>
     <div class="tactic-field"><label>Marcação</label><select id="marking"><option>Zona</option><option>Individual</option></select></div>
     <div class="tactic-field"><label>Largura</label><select id="width"><option>Fechada</option><option>Normal</option><option>Aberta</option></select></div>
     <div class="tactic-field"><label>Linha defensiva</label><select id="defensiveLine"><option>Baixa</option><option>Normal</option><option>Alta</option></select></div>
     <div class="tactic-field"><label>Bolas paradas</label><select id="setPieces"><option>Defensivo</option><option>Equilibrado</option><option>Ofensivo</option></select></div>
    </div>
    <div class="tactic-summary">
      <div><b id="attackScore">80</b><span>INTENSIDADE</span></div>
      <div><b id="balanceScore">80</b><span>EQUILÍBRIO</span></div>
      <div><b id="riskScore">20</b><span>RISCO</span></div>
      <div><b id="pressScore">80</b><span>PRESSÃO</span></div>
    </div>
   </div>
   <div class="tactic-card"><h2>Dica do treinador</h2><p id="tip" class="muted"></p></div>
  </section>
 </div>`;

function allowedPosition(slot){
  const map={GOL:["GOL"],LAT:["LAT"],ZAG:["ZAG"],VOL:["VOL"],MEI:["MEI"],ATA:["ATA"]};
  return map[slot]||[];
}
function positionName(pos){
  return ({GOL:"Goleiro",ZAG:"Zagueiro",LAT:"Lateral",VOL:"Volante",MEI:"Meia",ATA:"Atacante"})[pos]||pos;
}
function renderStarters(){
   const box=document.getElementById("starterList");
   const players=s.squad||[];
   const spots=FORMATIONS[t.formation]||FORMATIONS["4-3-3"];
   // Ajusta a escalação para respeitar as posições da formação.
   const used=new Set();
   const xi=[];
   spots.forEach((sp,i)=>{
      const exact=(s.tacticalXI||[]).map(id=>players.find(p=>p.id===id)).find(p=>p && !used.has(p.id) && allowedPosition(sp[0]).includes(p.position));
      const fallback=players.find(p=>!used.has(p.id) && allowedPosition(sp[0]).includes(p.position));
      const chosen=exact||fallback;
      if(chosen){used.add(chosen.id);xi[i]=chosen.id;}
   });
   s.tacticalXI=xi.filter(Boolean);
   saveGame(s);

   box.innerHTML=`<h3 style="margin:15px 0 8px">Titulares por posição</h3>`+
    spots.map((sp,i)=>{
      const valid=players.filter(p=>allowedPosition(sp[0]).includes(p.position));
      const selected=s.tacticalXI[i];
      return `<div class="starter-row">
        <span>${i+1}. ${positionName(sp[0])}</span>
        <select data-starter="${i}">
          ${valid.map(p=>`<option value="${p.id}" ${selected===p.id?"selected":""}>${p.name} — OVR ${p.rating}</option>`).join("")}
        </select>
      </div>`;
    }).join("");
   box.querySelectorAll("[data-starter]").forEach(sel=>sel.onchange=()=>{
      const index=Number(sel.dataset.starter), newId=sel.value;
      const oldId=s.tacticalXI[index];
      // Impede dois jogadores iguais e mantém a posição da vaga.
      if(s.tacticalXI.includes(newId) && newId!==oldId){
        toast("Esse jogador já está em outra vaga.");
        renderStarters(); return;
      }
      s.tacticalXI[index]=newId;
      saveGame(s); renderBoard(s); toast("Titular alterado.");
   });
 }
 if(!s.tacticalXI) s.tacticalXI=[];
 document.getElementById("bestXI").onclick=()=>{
   const players=s.squad||[];
   const spots=FORMATIONS[t.formation]||FORMATIONS["4-3-3"];
   const used=new Set();
   const xi=[];
   spots.forEach((sp,i)=>{
      const valid=players.filter(p=>allowedPosition(sp[0]).includes(p.position) && !used.has(p.id))
        .sort((a,b)=>(b.rating||0)-(a.rating||0));
      if(valid[0]){ used.add(valid[0].id); xi[i]=valid[0].id; }
   });
   s.tacticalXI=xi.filter(Boolean);
   saveGame(s);
   renderStarters();
   renderBoard(s);
   toast("Melhores jogadores selecionados!");
 };
 renderStarters();

 const ids=["mentality","pressing","tempo","marking","width","defensiveLine","setPieces"];
 ids.forEach(id=>document.getElementById(id).value=t[id]);
 function refresh(){
   const current={...t};ids.forEach(id=>current[id]=document.getElementById(id).value);
   const intensity=calcTacticScore(current);
   const risk={Defensiva:12,Equilibrada:25,Ofensiva:40}[current.mentality];
   const balance=current.formation==="5-3-2"?88:current.formation==="3-4-3"?70:80;
   document.getElementById("attackScore").textContent=Math.min(99,intensity+(current.tempo==="Rápido"?5:0));
   document.getElementById("balanceScore").textContent=balance;
   document.getElementById("riskScore").textContent=risk;
   document.getElementById("pressScore").textContent=pressingValue(current.pressing);
   document.getElementById("tip").textContent = current.mentality==="Ofensiva"
    ? "A equipe busca o ataque com mais jogadores, mas deixa mais espaços."
    : current.mentality==="Defensiva"
    ? "A equipe protege mais a defesa e procura sair em contra-ataques."
    : "A equipe mantém um equilíbrio entre posse, defesa e ataque.";
 }
 function pressingValue(v){return v==="Alto"?90:v==="Baixo"?65:80}
 document.querySelectorAll("[data-formation]").forEach(b=>b.onclick=()=>{
   document.querySelectorAll("[data-formation]").forEach(x=>x.classList.remove("active"));
   b.classList.add("active");t.formation=b.dataset.formation;
   document.getElementById("formationName").textContent=t.formation;renderStarters();renderBoard(s);
 });
 ids.forEach(id=>document.getElementById(id).onchange=refresh);
 document.getElementById("saveTactic").onclick=()=>{
   ids.forEach(id=>t[id]=document.getElementById(id).value);
   saveGame(s);toast("Tática salva com sucesso!");
 };
 renderBoard(s);refresh();
});
