let simTimer=null;
document.addEventListener("DOMContentLoaded",()=>{
 const s=loadGame();if(!s)return;renderShell("Partida");const c=document.getElementById("pageContent"),f=currentFixture(s);
 if(!f){c.innerHTML=`<div class="empty">Não há partida disponível.</div>`;return}
 const home=getTeam(f.homeId),away=getTeam(f.awayId);
 c.innerHTML=`<div class="page-head"><div><p class="eyebrow">MATCH CENTER</p><h1>Rodada ${f.round}</h1><p>Simulação ao vivo da partida.</p></div></div>
 <section class="match-stage"><div class="versus"><div><div class="big-crest">${home.crest}</div><h2>${home.name}</h2><span class="badge">${f.homeId===s.clubId?"MANDANTE":""}</span></div>
 <div><div class="score" id="score">0 × 0</div><div class="muted" id="minute">Pré-jogo</div></div>
 <div><div class="big-crest">${away.crest}</div><h2>${away.name}</h2><span class="badge">${f.awayId===s.clubId?"VISITANTE":""}</span></div></div>
 <div class="sim-progress"><i id="progress"></i></div>
 <div id="events" class="match-events"><div class="event">O juiz apita e a partida vai começar.</div></div>
 <div class="match-stats" id="stats"></div>
 <div class="match-actions"><button id="start" class="btn primary">▶ Iniciar simulação</button></div></section>`;
 document.getElementById("start").onclick=()=>simulate(s,f);
});
function simulate(s,f){
 const btn=document.getElementById("start");btn.disabled=true;
 let min=0,hg=0,ag=0,events=[],shotsH=0,shotsA=0;
   let posH=50+Math.round((getTeam(f.homeId).strength-getTeam(f.awayId).strength)*0.7);
   posH=Math.max(38,Math.min(62,posH));
 const tactic=s.tactic||{formation:"4-3-3",mentality:"Equilibrada",pressing:"Médio",tempo:"Normal",marking:"Zona",width:"Normal",defensiveLine:"Normal",setPieces:"Equilibrado"};
 const isUserHome=f.homeId===s.clubId;
 const mentalityBonus={Defensiva:-4,Equilibrada:3,Ofensiva:8}[tactic.mentality]||0;
 const tempoBonus={Lento:-3,Normal:0,Rápido:5}[tactic.tempo]||0;
 const pressBonus={Baixo:-2,Médio:2,Alto:5}[tactic.pressing]||0;
 const formationBonus={"4-3-3":4,"4-4-2":2,"4-2-3-1":3,"3-5-2":2,"3-4-3":5,"5-3-2":0}[tactic.formation]||0;
 const userTacticBonus=isUserHome?mentalityBonus+tempoBonus+pressBonus+formationBonus:0;
 const goalChance=(getTeam(f.homeId).strength+ (isUserHome?3+userTacticBonus:0))*.00075;
 simTimer=setInterval(()=>{
   min+=2;document.getElementById("minute").textContent=min+"'";document.getElementById("progress").style.width=Math.min(100,min/90*100)+"%";
   const attack=Math.random();
   const homeAttackRate=Math.max(.08,Math.min(.24,.15+(isUserHome?userTacticBonus*.004:0)));
   const awayAttackRate=Math.max(.08,Math.min(.24,.15+(!isUserHome?userTacticBonus*.004:0)));
   if(attack<homeAttackRate){shotsH++;if(Math.random()<goalChance*3.2){hg++;const roster=s.allPlayers[f.homeId]||s.squad;const pool=roster.filter(p=>["ATA","MEI","VOL"].includes(p.position));const scorer=(pool.length?pool:roster)[Math.floor(Math.random()*(pool.length?pool.length:roster.length))];if(scorer)scorer.goals++;events.push({min,text:`⚽ ${scorer?scorer.name:"Gol"} (${getTeam(f.homeId).name})`});}}
   else if(attack>(1-awayAttackRate)){shotsA++;if(Math.random()<((getTeam(f.awayId).strength+(f.awayId===s.clubId?3+userTacticBonus:0))*.00075)*3.2){ag++;const roster=s.allPlayers[f.awayId]||[];const pool=roster.filter(p=>["ATA","MEI","VOL"].includes(p.position));const scorer=(pool.length?pool:roster)[Math.floor(Math.random()*(pool.length?pool.length:roster.length))];if(scorer)scorer.goals++;events.push({min,text:`⚽ ${scorer?scorer.name:"Gol"} (${getTeam(f.awayId).name})`});}}
   if(Math.random()<.035)events.push({min,text:"🟨 Cartão amarelo."});
   if(Math.random()<.025)events.push({min,text:"🔄 Substituição."});
   document.getElementById("score").textContent=`${hg} × ${ag}`;
   document.getElementById("events").innerHTML=events.slice().reverse().map(e=>`<div class="event"><span class="minute">${e.min}'</span>${e.text}</div>`).join("")||`<div class="event">Jogo equilibrado...</div>`;
   document.getElementById("stats").innerHTML=`<div class="match-stat"><strong>${shotsH}</strong><span class="muted">Finalizações casa</span></div><div class="match-stat"><strong>${posH}%</strong><span class="muted">Posse casa</span></div><div class="match-stat"><strong>${shotsA}</strong><span class="muted">Finalizações fora</span></div>`;
   if(min>=90){clearInterval(simTimer);finishMatch(s,f,hg,ag,events,shotsH,shotsA,posH);}
 },110);
}
function finishMatch(s,f,hg,ag,events,shotsH,shotsA,posH){
 f.events=events;registerResult(s,f,hg,ag);
 const isHome=f.homeId===s.clubId, gf=isHome?hg:ag,ga=isHome?ag:hg;
 const attendance=Math.round(getTeam(f.homeId).capacity*(.55+Math.random()*.35));payMatch(s,f.homeId,attendance);
 s.teamStats.shots+=isHome?shotsH:shotsA;s.teamStats.possession+=isHome?posH:100-posH;
 // O elenco registra uma participação média no jogo simulado.
 const xi=(s.tacticalXI||s.squad.slice(0,11).map(p=>p.id)); const activePlayers=xi.map(id=>s.squad.find(p=>p.id===id)).filter(p=>p&&p.morale>=50);
 activePlayers.forEach(p=>p.matches++);
 advanceRound(s);
 saveGame(s);
 document.getElementById("events").innerHTML += `<div class="event"><b>🏁 Fim de jogo: ${getTeam(f.homeId).name} ${hg} × ${ag} ${getTeam(f.awayId).name}</b></div>`;
 document.getElementById("stats").innerHTML += `<div class="match-stat"><strong>${attendance.toLocaleString("pt-BR")}</strong><span class="muted">Público</span></div>`;
 document.getElementById("start").disabled=false;document.getElementById("start").textContent="↻ Próxima partida";document.getElementById("start").onclick=()=>location.reload();
}
