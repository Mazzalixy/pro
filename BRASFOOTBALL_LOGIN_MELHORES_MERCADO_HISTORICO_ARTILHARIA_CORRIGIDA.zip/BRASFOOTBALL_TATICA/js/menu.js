document.addEventListener("DOMContentLoaded",()=>{
 const s=loadGame(); if(!s)return; renderShell("Menu"); const c=document.getElementById("pageContent"), f=currentFixture(s);
 const pos=sortedStandings(s).findIndex(x=>x.teamId===s.clubId)+1;
 c.innerHTML=`
 <div class="page-head"><div><p class="eyebrow">CENTRAL DO TREINADOR</p><h1>Bem-vindo ao BRASFOOTBALL ⚽</h1><p>Controle seu clube e avance a temporada.</p></div><a class="btn primary" href="partida.html">⚽ Ir para a partida</a></div>
 <div class="grid-4">
   <div class="stat-card"><span class="icon">🏆</span><small>Posição</small><strong>${pos}º</strong></div>
   <div class="stat-card"><span class="icon">💰</span><small>Saldo</small><strong>${money(s.finance.balance)}</strong></div>
   <div class="stat-card"><span class="icon">⚽</span><small>Gols marcados</small><strong>${s.teamStats.goalsFor}</strong></div>
   <div class="stat-card"><span class="icon">📅</span><small>Rodada</small><strong>${s.round}/38</strong></div>
 </div>
 <div class="hero-grid" style="margin-top:18px">
  <section class="panel"><div class="panel-title"><div><h2>Próximo jogo</h2><p>Rodada ${f?.round||"-"}</p></div><span class="badge gold">CAMPEONATO</span></div>
   ${f?`<div class="next-match" style="margin-top:22px"><div class="team"><div class="crest">${teamObj(f.homeId).crest}</div><b>${teamName(f.homeId)}</b></div><div class="scorebox">VS</div><div class="team"><div class="crest">${teamObj(f.awayId).crest}</div><b>${teamName(f.awayId)}</b></div></div>`:`<div class="empty">Temporada encerrada.</div>`}
  </section>
  <section class="panel"><h2>Objetivo</h2><p class="muted">${s.objective}</p><div class="progress"><i style="width:${Math.max(5,Math.min(100,(9-pos)*12))}%"></i></div><p class="muted" style="margin-bottom:0">Você está em <b>${pos}º lugar</b>.</p></section>
 </div>
 <section class="panel" style="margin-top:18px"><h2>Atalhos</h2><div class="grid-3">
   <a class="btn secondary" href="elenco.html">👥 Gerenciar elenco</a><a class="btn secondary" href="tactica.html">🎯 Montar tática</a><a class="btn secondary" href="mercado.html">💰 Abrir mercado</a><a class="btn secondary" href="classificacao.html">📊 Ver classificação</a>
 </div></section>`;
});
