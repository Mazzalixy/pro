document.addEventListener("DOMContentLoaded",()=>{
 const s=loadGame();if(!s)return;renderShell("Artilharia");const c=document.getElementById("pageContent");
 const arr=globalScorers(s).slice(0,50);
 c.innerHTML=`<div class="page-head"><div><p class="eyebrow">GOLS</p><h1>Artilharia</h1><p>Todos os 20 clubes participam da artilharia. Ranking atualizado a cada rodada.</p></div></div>
 <section class="panel"><div class="muted" style="margin-bottom:12px">20 clubes no campeonato • ${new Set(globalScorers(s).map(p=>p.teamId)).size} clubes com jogadores registrados</div>${arr.length?`<div style="overflow:auto"><table><thead><tr><th>#</th><th>Jogador</th><th>Clube</th><th>Pos.</th><th>Gols</th></tr></thead><tbody>${arr.map((p,i)=>`<tr><td class="scorer-rank">${i+1}</td><td><b>${p.name}</b></td><td>${teamName(p.teamId)}</td><td>${p.position}</td><td><b>${p.goals}</b></td></tr>`).join("")}</tbody></table></div>`:`<div class="empty">Os gols aparecerão aqui depois das partidas.</div>`}</section>`;
});
