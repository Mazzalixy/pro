document.addEventListener("DOMContentLoaded",()=>{
 const s=loadGame();if(!s)return;renderShell("Campeonato");const c=document.getElementById("pageContent"),stand=sortedStandings(s),f=currentFixture(s);
 c.innerHTML=`<div class="page-head"><div><p class="eyebrow">COMPETIÇÃO</p><h1>Campeonato Nacional</h1><p>Temporada ${s.season} • 20 clubes • 38 rodadas</p></div></div>
 <div class="competition-banner"><h2>🏆 Campeonato Nacional</h2><p>Seu próximo desafio: ${f?teamName(f.homeId===s.clubId?f.awayId:f.homeId):"fim da temporada"}</p></div>
 <section class="panel"><div class="panel-title"><h2>Classificação</h2><a class="btn secondary" href="classificacao.html">Tela completa</a></div><div class="table-wrap"><table><thead><tr><th>#</th><th>Clube</th><th>J</th><th>V</th><th>E</th><th>D</th><th>SG</th><th>Pts</th></tr></thead><tbody>
 ${stand.slice(0,10).map((x,i)=>`<tr class="${x.teamId===s.clubId?"my-row":""}"><td>${i+1}</td><td>${teamObj(x.teamId).crest} <b>${teamName(x.teamId)}</b></td><td>${x.p}</td><td>${x.w}</td><td>${x.d}</td><td>${x.l}</td><td>${x.gd}</td><td><b>${x.pts}</b></td></tr>`).join("")}</tbody></table></div></section>`;
});
