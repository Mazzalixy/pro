document.addEventListener("DOMContentLoaded",()=>{
 const s=loadGame();if(!s)return;renderShell("Elenco");const c=document.getElementById("pageContent");
 c.innerHTML=`<div class="page-head"><div><p class="eyebrow">PLANTEL</p><h1>Elenco</h1><p>${s.squad.length} jogadores sob contrato.</p></div></div>
 <section class="panel"><div class="filters"><input id="search" class="input" placeholder="Pesquisar jogador..."><select id="pos" class="select"><option value="">Todas posições</option>${POSITIONS.map(x=>`<option>${x}</option>`).join("")}</select></div>
 <div style="overflow:auto"><table><thead><tr><th>Jogador</th><th>Pos.</th><th>Idade</th><th>Força</th><th>Forma</th><th>Gols</th><th>Valor</th></tr></thead><tbody id="players"></tbody></table></div></section>`;
 const render=()=>{const q=document.getElementById("search").value.toLowerCase(),p=document.getElementById("pos").value;
 document.getElementById("players").innerHTML=s.squad.filter(x=>(x.name.toLowerCase().includes(q))&&(!p||x.position===p)).map(x=>`<tr><td><div class="player-name"><div class="player-avatar">👤</div><div><b>${x.name}</b><div class="pos">${x.position}</div></div></div></td><td>${x.position}</td><td>${x.age}</td><td class="rating">${x.rating}</td><td><span class="badge ${x.form>=75?"green":x.form<60?"red":""}">${x.form}</span></td><td>${x.goals}</td><td>${money(x.price)}</td></tr>`).join("")};
 document.getElementById("search").oninput=render;document.getElementById("pos").onchange=render;render();
});
