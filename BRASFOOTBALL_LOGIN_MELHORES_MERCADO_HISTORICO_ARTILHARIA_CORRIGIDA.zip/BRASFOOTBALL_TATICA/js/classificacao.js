document.addEventListener("DOMContentLoaded",()=>{
 const s=loadGame();if(!s)return;renderShell("Classificação");const c=document.getElementById("pageContent"),stand=sortedStandings(s);
 c.innerHTML=`<div class="page-head"><div><p class="eyebrow">TABELA</p><h1>Classificação</h1><p>Temporada ${s.season} • Atualizada após cada partida.</p></div></div>
 <section class="panel"><div style="overflow:auto"><table><thead><tr><th>#</th><th>Clube</th><th>J</th><th>V</th><th>E</th><th>D</th><th>GP</th><th>GC</th><th>SG</th><th>PTS</th></tr></thead><tbody>
 ${stand.map((x,i)=>`<tr class="${x.teamId===s.clubId?"my-row":""}"><td class="rank">${i+1}</td><td>${teamObj(x.teamId).crest} <b>${teamName(x.teamId)}</b></td><td>${x.p}</td><td>${x.w}</td><td>${x.d}</td><td>${x.l}</td><td>${x.gf}</td><td>${x.ga}</td><td>${x.gd}</td><td><b>${x.pts}</b></td></tr>`).join("")}</tbody></table></div></section>`;
});
