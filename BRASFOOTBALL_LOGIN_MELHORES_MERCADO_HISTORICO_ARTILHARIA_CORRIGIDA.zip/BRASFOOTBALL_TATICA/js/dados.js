const GAME_TEAMS = [
 {id:"aurora",name:"Aurora FC",short:"AUR",strength:84,crest:"🟢",city:"São Paulo",stadium:"Estádio Aurora",capacity:48000},
 {id:"realbrasil",name:"Real Brasil",short:"RBR",strength:82,crest:"🔵",city:"Rio de Janeiro",stadium:"Arena Brasil",capacity:52000},
 {id:"uniao",name:"União Nacional",short:"UNA",strength:80,crest:"🟡",city:"Belo Horizonte",stadium:"Estádio União",capacity:41000},
 {id:"metropole",name:"Metrópole FC",short:"MET",strength:79,crest:"🔴",city:"Porto Alegre",stadium:"Arena Metrópole",capacity:46000},
 {id:"atlantic",name:"Atlântico",short:"ATL",strength:78,crest:"⚫",city:"Salvador",stadium:"Arena Atlântico",capacity:39000},
 {id:"bravos",name:"Bravos FC",short:"BRA",strength:77,crest:"🟠",city:"Curitiba",stadium:"Bravos Park",capacity:37000},
 {id:"sertao",name:"Sertão Clube",short:"SER",strength:75,crest:"🟣",city:"Recife",stadium:"Estádio Sertão",capacity:33000},
 {id:"capital",name:"Capital Esporte",short:"CAP",strength:74,crest:"🔵",city:"Brasília",stadium:"Arena Capital",capacity:44000},
 {id:"litoral",name:"Litoral FC",short:"LIT",strength:73,crest:"🌊",city:"Santos",stadium:"Vila Litoral",capacity:32000},
 {id:"ferroviario",name:"Ferroviário",short:"FER",strength:72,crest:"🚂",city:"Campinas",stadium:"Locomotiva",capacity:28000},
 {id:"verdevale",name:"Verde Vale",short:"VVE",strength:70,crest:"🌿",city:"Goiânia",stadium:"Vale Arena",capacity:30000},
 {id:"montanha",name:"Montanha FC",short:"MON",strength:68,crest:"⛰️",city:"Caxias do Sul",stadium:"Estádio Montanha",capacity:26000},
 {id:"estrela",name:"Estrela Azul",short:"EAZ",strength:67,crest:"⭐",city:"Belém",stadium:"Estrela Park",capacity:25000},
 {id:"guarani",name:"Guará Esporte",short:"GUA",strength:66,crest:"🦊",city:"Fortaleza",stadium:"Guará Arena",capacity:31000},
 {id:"pioneiros",name:"Pioneiros FC",short:"PIO",strength:64,crest:"🟤",city:"Manaus",stadium:"Pioneiros",capacity:22000},
 {id:"imperio",name:"Império SC",short:"IMP",strength:62,crest:"👑",city:"Vitória",stadium:"Arena Império",capacity:24000},
 {id:"rioverde",name:"Rio Verde",short:"RVD",strength:61,crest:"💚",city:"Campo Grande",stadium:"Verde Arena",capacity:21000},
 {id:"nordeste",name:"Nordeste FC",short:"NOR",strength:60,crest:"🟥",city:"Natal",stadium:"Arena Nordeste",capacity:23000},
 {id:"fronteira",name:"Fronteira",short:"FRO",strength:58,crest:"🛡️",city:"Foz do Iguaçu",stadium:"Fronteira Park",capacity:19000},
 {id:"unidos",name:"Unidos FC",short:"UNI",strength:56,crest:"⚽",city:"Maceió",stadium:"Estádio Unidos",capacity:18000}
];

const FIRST_NAMES = ["Lucas","Pedro","Gabriel","Rafael","João","Mateus","Arthur","Davi","Henrique","Caio","Bruno","Gustavo","Diego","Felipe","Murilo","Vinícius","Enzo","Samuel","André","Thiago","Leonardo","Victor","Eduardo","Matheus","Nicolas","Igor","Daniel","Luan","Alex","Renan"];
const LAST_NAMES = ["Silva","Santos","Oliveira","Costa","Souza","Lima","Almeida","Ferreira","Pereira","Carvalho","Mendes","Ribeiro","Martins","Gomes","Rocha","Barbosa","Teixeira","Moura","Nunes","Freitas"];
const POSITIONS = ["GOL","LAT","ZAG","VOL","MEI","ATA"];

function makePlayers(team, index) {
  const roles = ["GOL","GOL","GOL","LAT","LAT","LAT","LAT","ZAG","ZAG","ZAG","ZAG","ZAG","ZAG","VOL","VOL","VOL","VOL","MEI","MEI","MEI","MEI","ATA","ATA","ATA","ATA"];
  return roles.map((pos,i)=>{
    const base = team.strength + Math.round((Math.random()*10)-5);
    const age = 18 + ((index*7+i*3)%19);
    const name = FIRST_NAMES[(index*3+i)%FIRST_NAMES.length] + " " + LAST_NAMES[(index*5+i*2)%LAST_NAMES.length];
    const rating = Math.max(45, Math.min(92, base + (pos==="ATA"||pos==="MEI"?2:0)));
    return {id:`${team.id}-${i}`,name,position:pos,age,rating,price:Math.round((rating*rating*1200)*(1+(25-age)/100)),teamId:team.id,goals:0,assists:0,cards:0,matches:0,morale:75,form:Math.round(60+Math.random()*30)};
  });
}
