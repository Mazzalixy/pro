document.addEventListener("DOMContentLoaded",()=>{
 const s=loadGame();if(!s)return;renderShell("Clube");const t=getTeam(s.clubId),pos=sortedStandings(s).findIndex(x=>x.teamId===s.clubId)+1,c=document.getElementById("pageContent");
 c.innerHTML=`<div class="page-head"><div><p class="eyebrow">MEU CLUBE</p><h1>Informações do clube</h1><p>Estrutura, desempenho e identidade.</p></div></div>
 <section class="panel"><div class="club-hero"><div class="club-crest">${t.crest}</div><div><p class="eyebrow">${t.city}</p><h2 class="club-name">${t.name}</h2><p class="muted">Força geral: <b>${t.strength}</b></p></div></div></section>
 <div class="grid-2" style="margin-top:18px"><section class="panel"><h2>Estrutura</h2><div class="detail-list">
 <div class="detail"><small>Estádio</small><b>${t.stadium}</b></div><div class="detail"><small>Capacidade</small><b>${t.capacity.toLocaleString("pt-BR")} lugares</b></div>
 <div class="detail"><small>Torcida</small><b>${Math.round(t.capacity*.78).toLocaleString("pt-BR")}</b></div><div class="detail"><small>Títulos</small><b>${s.trophies}</b></div></div></section>
 <section class="panel"><h2>Temporada ${s.season}</h2><div class="detail-list"><div class="detail"><small>Posição</small><b>${pos}º</b></div><div class="detail"><small>Jogos</small><b>${s.teamStats.played}</b></div><div class="detail"><small>Vitórias</small><b>${s.teamStats.wins}</b></div><div class="detail"><small>Derrotas</small><b>${s.teamStats.losses}</b></div></div></section></div>`;
});
