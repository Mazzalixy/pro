document.addEventListener("DOMContentLoaded",()=>{
 const s=loadGame();if(!s)return;
 renderShell("Mercado");
 const c=document.getElementById("pageContent");

 function addMarketHistory(type, description, value=0, status="Concluída"){
   if(!s.marketHistory) s.marketHistory=[];
   s.marketHistory.unshift({
     date:new Date().toLocaleDateString("pt-BR"),
     time:new Date().toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"}),
     type, description, value, status
   });
   s.marketHistory=s.marketHistory.slice(0,150);
 }

 rebuildMarket();
 render();

 function rebuildMarket(){
   // O mercado agora mostra jogadores de TODOS os outros clubes,
   // em vez de limitar a alguns jogadores por posição.
   s.market=GAME_TEAMS
     .filter(t=>t.id!==s.clubId)
     .flatMap(t=>(s.allPlayers[t.id]||[]).map(p=>({
       ...p,
       id:`m-${t.id}-${p.id}`,
       originalId:p.id,
       ownerId:t.id,
       ownerName:t.name
     })));
   saveGame(s);
 }

 function posLabel(pos){
   return ({GOL:"🧤 Goleiro",ZAG:"🛡️ Zagueiro",VOL:"⚙️ Volante",MEI:"🎯 Meia",ATA:"⚡ Atacante",LAT:"↔️ Lateral"})[pos]||pos;
 }

 function render(){
   const positions=["TODOS","GOL","ZAG","VOL","MEI","ATA","LAT"];
   const counts=Object.fromEntries(positions.map(x=>[
     x,x==="TODOS"?s.market.length:s.market.filter(p=>p.position===x).length
   ]));

   c.innerHTML=`
   <div class="page-head">
     <div>
       <p class="eyebrow">TRANSFERÊNCIAS</p>
       <h1>Mercado de jogadores 💰</h1>
       <p>Todos os clubes podem contratar jogadores. Há opções de todas as posições.</p>
     </div>
     <div class="money">${money(s.finance.balance)}</div>
   </div>

   <div class="market-tabs" id="marketTabs">
    ${positions.map(x=>`<button class="btn secondary ${x==="TODOS"?"active":""}" data-pos="${x}">
      ${x==="TODOS"?"👥 Todos":posLabel(x)} <small>(${counts[x]})</small>
    </button>`).join("")}
   </div>

   <section class="card" style="margin-top:15px">
    <div class="panel-title">
      <div><h2>Jogadores disponíveis</h2><p class="muted">${s.market.length} jogadores disponíveis no mercado.</p></div>
      <input id="marketSearch" class="input" placeholder="🔎 Buscar jogador...">
    </div>
    <div id="marketGrid" class="market-grid"></div>
   </section>

   <section class="card" style="margin-top:15px">
    <div class="panel-title">
      <div><h2>Histórico do mercado</h2><p class="muted">Compras, vendas e negociações recusadas da sua carreira.</p></div>
      <select id="historyFilter" class="input" style="max-width:180px">
        <option value="TODOS">Todos</option>
        <option value="Compra">Compras</option>
        <option value="Venda">Vendas</option>
        <option value="Recusação">Recusações</option>
      </select>
    </div>
    <div id="marketHistoryList"></div>
   </section>

   <section class="card" style="margin-top:15px">
    <div class="panel-title">
      <div><h2>Trocar jogador</h2><p class="muted">Troque um jogador do seu elenco por outro disponível.</p></div>
    </div>
    <div class="trade-grid">
      <div><label>Seu jogador</label><select id="sellSelect"></select></div>
      <div><label>Jogador do mercado</label><select id="buySelect"></select></div>
      <button id="tradeBtn" class="btn primary">🔄 Fazer troca</button>
    </div>
   </section>`;

   let currentPos="TODOS";
   const tabs=[...document.querySelectorAll("[data-pos]")];
   const grid=document.getElementById("marketGrid");

   function draw(){
     const q=document.getElementById("marketSearch").value.toLowerCase();
     const arr=s.market.filter(p=>
       (currentPos==="TODOS"||p.position===currentPos) &&
       p.name.toLowerCase().includes(q)
     );

     grid.innerHTML=arr.map(p=>`
       <article class="market-player">
        <div class="player-avatar">${p.position==="GOL"?"🧤":"⚽"}</div>
        <div class="market-info">
          <h3>${p.name}</h3>
          <span>${posLabel(p.position)} • ${p.age} anos</span>
          <div class="player-meta">
            <b>OVR ${p.rating}</b>
            <span>${money(p.price)}</span>
          </div>
          <small class="muted">Clube: ${p.ownerName||teamName(p.ownerId)}</small>
        </div>
        <button class="btn primary buy" data-id="${p.id}"
          ${s.finance.balance<p.price?"disabled":""}>Comprar</button>
       </article>`).join("") ||
       `<div class="empty">Nenhum jogador encontrado.</div>`;

     grid.querySelectorAll(".buy").forEach(b=>b.onclick=()=>buy(b.dataset.id));
     updateSelects();
   }

   tabs.forEach(b=>b.onclick=()=>{
     tabs.forEach(x=>x.classList.remove("active"));
     b.classList.add("active");
     currentPos=b.dataset.pos;
     draw();
   });
   document.getElementById("marketSearch").oninput=draw;
   document.getElementById("tradeBtn").onclick=trade;
   document.getElementById("historyFilter").onchange=drawHistory;

   function drawHistory(){
     const box=document.getElementById("marketHistoryList");
     const filter=document.getElementById("historyFilter").value;
     const rows=(s.marketHistory||[]).filter(h=>filter==="TODOS"||h.type===filter).slice(0,30);
     if(!rows.length){box.innerHTML='<div class="empty">Nenhuma movimentação de mercado registrada.</div>';return;}
     box.innerHTML=rows.map(h=>{
       const cls=h.type==="Compra"?"market-history-buy":h.type==="Venda"?"market-history-sell":"market-history-refuse";
       const val=h.value?money(h.value):"—";
       return `<div class="market-history-row ${cls}">
         <div><b>${h.type}</b><span>${h.description}</span><small>${h.date} ${h.time||""}</small></div>
         <strong>${val}</strong><em>${h.status}</em>
       </div>`;
     }).join("");
   }

   function updateSelects(){
     const ss=document.getElementById("sellSelect");
     const bs=document.getElementById("buySelect");
     ss.innerHTML=s.squad.map(p=>
       `<option value="${p.id}">${p.name} — ${p.position} — OVR ${p.rating}</option>`
     ).join("");
     bs.innerHTML=s.market.map(p=>
       `<option value="${p.id}">${p.name} — ${p.position} — OVR ${p.rating} — ${money(p.price)}</option>`
     ).join("");
   }

   function buy(id){
     const p=s.market.find(x=>x.id===id);
     if(!p)return;
     if(s.finance.balance<p.price){
       addMarketHistory("Recusação", `Compra recusada de ${p.name} — saldo insuficiente`, p.price, "Recusada");
       saveGame(s); drawHistory();
       toast("Compra recusada: saldo insuficiente.");
       return;
     }

     const sellerId=p.ownerId;
     const sellerRoster=s.allPlayers[sellerId]||[];
     const sellerIndex=sellerRoster.findIndex(x=>x.id===p.originalId);
     if(sellerIndex<0){
       addMarketHistory("Recusação", `Compra recusada de ${p.name} — jogador não está mais disponível`, p.price, "Recusada");
       saveGame(s);
       toast("Compra recusada: jogador indisponível.");
       rebuildMarket();
       render();
       return;
     }

     s.finance.balance-=p.price;
     s.finance.expenses+=p.price;
     s.finance.history.unshift({
       date:new Date().toLocaleDateString("pt-BR"),
       type:"Despesa",
       description:`Compra de ${p.name}`,
       value:p.price
     });
     addMarketHistory("Compra", `${p.name} — ${p.ownerName||teamName(p.ownerId)} → ${teamName(s.clubId)}`, p.price, "Concluída");

     const bought={...sellerRoster[sellerIndex],teamId:s.clubId};
     sellerRoster.splice(sellerIndex,1);
     s.allPlayers[sellerId]=sellerRoster;
     s.squad.push(bought);
     s.allPlayers[s.clubId]=clone(s.squad);

     saveGame(s);
     toast(`${p.name} contratado!`);
     rebuildMarket();
     render();
   }

   function trade(){
     const out=s.squad.find(p=>p.id===document.getElementById("sellSelect").value);
     const inc=s.market.find(p=>p.id===document.getElementById("buySelect").value);
     if(!out||!inc)return;

     const sellerId=inc.ownerId;
     const sellerRoster=s.allPlayers[sellerId]||[];
     const incomingIndex=sellerRoster.findIndex(p=>p.id===inc.originalId);
     if(incomingIndex<0){
       addMarketHistory("Recusação", `Troca recusada: ${inc.name} não está mais disponível`, inc.price, "Recusada");
       saveGame(s);
       toast("Troca recusada: jogador indisponível.");
       rebuildMarket();
       render();
       return;
     }

     const fee=Math.max(0,Math.round((inc.price-out.price)*0.12));
     if(s.finance.balance<fee){
       addMarketHistory("Recusação", `Troca recusada: ${out.name} por ${inc.name} — taxa insuficiente`, fee, "Recusada");
       saveGame(s); drawHistory();
       toast(`Troca recusada: você precisa de ${money(fee)}.`);
       return;
     }

     s.finance.balance-=fee;
     s.finance.expenses+=fee;
     s.finance.history.unshift({
       date:new Date().toLocaleDateString("pt-BR"),
       type:"Despesa",
       description:`Taxa de troca: ${out.name} por ${inc.name}`,
       value:fee
     });
     addMarketHistory("Venda", `${out.name} — ${teamName(s.clubId)} → ${teamName(sellerId)}`, out.price||0, "Concluída");
     addMarketHistory("Compra", `${inc.name} — ${teamName(sellerId)} → ${teamName(s.clubId)}`, inc.price||0, "Concluída");

     const incoming={...sellerRoster[incomingIndex],teamId:s.clubId};
     sellerRoster.splice(incomingIndex,1);

     const outgoing={...out,teamId:sellerId,price:Math.max(50000,Math.round(out.price*.9))};
     sellerRoster.push(outgoing);

     const squadIndex=s.squad.findIndex(p=>p.id===out.id);
     s.squad[squadIndex]=incoming;
     s.allPlayers[sellerId]=sellerRoster;
     s.allPlayers[s.clubId]=clone(s.squad);

     saveGame(s);
     toast(`Troca realizada: ${out.name} → ${inc.name}`);
     rebuildMarket();
     render();
   }

   draw();
   drawHistory();
 }
});