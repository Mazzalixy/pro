const SAVE_KEY = "brasfootball_save_v3";

function money(v){return "R$ " + Number(v||0).toLocaleString("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2});}
function getTeam(id){return GAME_TEAMS.find(t=>t.id===id);}
function clone(x){return JSON.parse(JSON.stringify(x));}
function toast(msg){const x=document.createElement("div");x.className="toast";x.textContent=msg;document.body.appendChild(x);setTimeout(()=>x.remove(),2300);}
function loadGame(){try{return JSON.parse(localStorage.getItem(SAVE_KEY));}catch(e){return null;}}
function saveGame(s){localStorage.setItem(SAVE_KEY,JSON.stringify(s));}
function teamName(id){return getTeam(id)?.name||"Clube";}
function teamObj(id){return getTeam(id)||{};}

function createSchedule(teamIds){
  const arr=[...teamIds], n=arr.length, rounds=[];
  let list=arr.slice();
  for(let r=0;r<n-1;r++){
    const games=[];
    for(let i=0;i<n/2;i++){
      const a=list[i], b=list[n-1-i];
      const home=((r+i)%2===0)?a:b, away=((r+i)%2===0)?b:a;
      games.push({homeId:home,awayId:away,played:false,homeGoals:null,awayGoals:null,events:[]});
    }
    rounds.push(games);
    list=[list[0],list[n-1],...list.slice(1,n-1)];
  }
  const second=rounds.map(games=>games.map(g=>({homeId:g.awayId,awayId:g.homeId,played:false,homeGoals:null,awayGoals:null,events:[]})));
  return rounds.concat(second).map((games,i)=>({round:i+1,games}));
}

function initialStandings(teamIds){
  const x={}; teamIds.forEach(id=>x[id]={teamId:id,p:0,w:0,d:0,l:0,gf:0,ga:0,gd:0,pts:0});
  return x;
}
function newCareer(teamId){
  const team=getTeam(teamId);
  const allPlayers={};
  GAME_TEAMS.forEach((t,i)=>allPlayers[t.id]=makePlayers(t,i));
  const squad=clone(allPlayers[teamId]);
  // O mercado é reconstruído a partir dos elencos de todos os clubes.
  // Isso deixa todos os clubes aptos a comprar jogadores durante a temporada.
  const market=[];
  const ids=GAME_TEAMS.map(t=>t.id);
  const state={
    version:3,season:2026,round:1,clubId:teamId,squad,market,
    allPlayers, schedule:createSchedule(ids), standings:initialStandings(ids),
    finance:{balance:15000000,income:0,expenses:0,history:[{date:new Date().toLocaleDateString("pt-BR"),type:"Receita",description:"Patrocínio inicial",value:15000000}]},
    marketHistory:[],
    teamStats:{played:0,wins:0,draws:0,losses:0,goalsFor:0,goalsAgainst:0,shots:0,possession:0},
    settings:{sound:true,compact:false},
    tactic:{
      formation:"4-3-3",
      mentality:"Equilibrada",
      pressing:"Médio",
      tempo:"Normal",
      marking:"Zona",
      width:"Normal",
      defensiveLine:"Normal",
      setPieces:"Equilibrado"
    },
    trophies:0,objective:`Terminar entre os 8 primeiros`,
    lastMatch:null
  };
  saveGame(state); return state;
}
function startNewCareer(teamId){newCareer(teamId);location.href="menu.html";}
function resetCareer(){localStorage.removeItem(SAVE_KEY);location.href="index.html";}
function applySettings(s){document.body.classList.toggle("compact",!!s.settings?.compact);}
function navItems(){
  return [
    ["menu.html","🏠","Menu"],["clube.html","🏟️","Clube"],["elenco.html","👥","Elenco"],["mercado.html","💰","Mercado"],
    ["campeonato.html","🏆","Campeonato"],["jogos.html","📅","Jogos"],["tactica.html","🎯","Tática"],["partida.html","⚽","Partida"],
    ["classificacao.html","📊","Classificação"],["artilharia.html","🥅","Artilharia"],["estatisticas.html","📈","Estatísticas"],
    ["financas.html","💵","Finanças"],["configuracoes.html","⚙️","Configurações"]
  ];
}
function renderShell(title){
  const s=loadGame(); if(!s){location.href="index.html";return;}
  const team=getTeam(s.clubId);
  const current=document.body.dataset.page||"menu";
  document.getElementById("app").innerHTML=`
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand"><div class="ball">⚽</div><div><b>BRASFOOTBALL</b><span>MANAGER</span></div></div>
        <nav class="nav">${navItems().map(([href,icon,label])=>`<a class="${current===href.split(".")[0]?"active":""}" href="${href}"><span>${icon}</span>${label}</a>`).join("")}</nav>
      </aside>
      <main class="main">
        <header class="topbar">
          <div class="topbar-left"><span class="badge green">${team.crest} ${team.short}</span><div><h3>${team.name}</h3><div class="round">Temporada ${s.season} • Rodada ${s.round}/38</div></div></div>
          <div class="money">${money(s.finance.balance)}</div>
        </header>
        <div id="pageContent"></div>
      </main>
    </div>`;
  applySettings(s);
}
function currentFixture(s){
  for(const rd of s.schedule){
    for(const g of rd.games){
      if(!g.played && (g.homeId===s.clubId||g.awayId===s.clubId)){
        g.round = rd.round;
        return g;
      }
    }
  }
  return null;
}
function recalcStandings(s){
  s.standings=initialStandings(GAME_TEAMS.map(t=>t.id));
  for(const rd of s.schedule) for(const g of rd.games){
    if(!g.played) continue;
    const h=s.standings[g.homeId], a=s.standings[g.awayId], hg=g.homeGoals, ag=g.awayGoals;
    h.p++;a.p++;h.gf+=hg;h.ga+=ag;a.gf+=ag;a.ga+=hg;h.gd=h.gf-h.ga;a.gd=a.gf-a.ga;
    if(hg>ag){h.w++;a.l++;h.pts+=3}else if(hg<ag){a.w++;h.l++;a.pts+=3}else{h.d++;a.d++;h.pts++;a.pts++}
  }
}
function sortedStandings(s){
  recalcStandings(s);
  return Object.values(s.standings).sort((a,b)=>b.pts-a.pts||b.gd-a.gd||b.gf-a.gf);
}
function completeSeasonIfNeeded(s){
  if(s.round>38){
    const pos=sortedStandings(s).findIndex(x=>x.teamId===s.clubId)+1;
    s.trophies += pos===1?1:0;
    s.season++;
    s.round=1;
    s.schedule=createSchedule(GAME_TEAMS.map(t=>t.id));
    s.standings=initialStandings(GAME_TEAMS.map(t=>t.id));
    Object.values(s.allPlayers).forEach(roster=>roster.forEach(p=>{p.goals=0;p.assists=0;p.cards=0;p.matches=0}));
    s.squad = clone(s.allPlayers[s.clubId] || s.squad);
    s.finance.history.unshift({date:new Date().toLocaleDateString("pt-BR"),type:"Prêmio",description:pos===1?"Título do campeonato":"Bônus de temporada",value:pos===1?5000000:500000});
    s.finance.balance+=(pos===1?5000000:500000);
    s.finance.income+=(pos===1?5000000:500000);
    toast(`Nova temporada ${s.season}!`);
  }
}
function registerResult(s,fixture,hg,ag){
  fixture.played=true;fixture.homeGoals=hg;fixture.awayGoals=ag;
  recalcStandings(s);
  if(fixture.homeId===s.clubId||fixture.awayId===s.clubId){
    const gf=fixture.homeId===s.clubId?hg:ag, ga=fixture.homeId===s.clubId?ag:hg;
    s.teamStats.played++;s.teamStats.goalsFor+=gf;s.teamStats.goalsAgainst+=ga;
    if(gf>ga)s.teamStats.wins++;else if(gf===ga)s.teamStats.draws++;else s.teamStats.losses++;
  }
  saveGame(s);
}
function payMatch(s,homeId,attendance){
  const home=getTeam(homeId);
  const income=Math.round(attendance*35);
  s.finance.balance+=income;s.finance.income+=income;
  s.finance.history.unshift({date:new Date().toLocaleDateString("pt-BR"),type:"Receita",description:`Bilheteria - ${home.name}`,value:income});
}
function randomScorer(roster){
  if(!roster || !roster.length) return null;
  const weighted=[];
  roster.forEach(p=>{
    const weight=p.position==="ATA"?6:p.position==="MEI"?4:p.position==="VOL"?2:1;
    for(let i=0;i<weight;i++) weighted.push(p);
  });
  return weighted[Math.floor(Math.random()*weighted.length)] || roster[0];
}

function simulateOtherMatches(s){
  // Todos os 20 clubes jogam em todas as rodadas.
  // Além do placar, cada gol é atribuído a um jogador do clube,
  // alimentando a artilharia geral do campeonato.
  const rd = s.schedule.find(x=>x.round===s.round);
  if(!rd) return;
  for(const g of rd.games){
    if(g.played) continue;

    const home=getTeam(g.homeId), away=getTeam(g.awayId);
    const homeAdv=2;
    const homeChance=Math.max(0.15, Math.min(0.78,
      0.50 + (home.strength-away.strength)*0.025 + homeAdv*0.01
    ));
    let hg=0, ag=0;
    const scorers=[];
    const totalGoals=Math.random()<0.18?0:Math.floor(Math.random()*5);
    for(let i=0;i<totalGoals;i++){
      if(Math.random()<homeChance){
        hg++;
        const p=randomScorer(s.allPlayers[g.homeId]);
        if(p){p.goals++;scorers.push({teamId:g.homeId,playerId:p.id,player:p.name,min:10+Math.floor(Math.random()*80)});}
      }else{
        ag++;
        const p=randomScorer(s.allPlayers[g.awayId]);
        if(p){p.goals++;scorers.push({teamId:g.awayId,playerId:p.id,player:p.name,min:10+Math.floor(Math.random()*80)});}
      }
    }
    if(Math.random()<0.10){
      // Varia alguns placares sem perder a contagem de artilharia.
      hg=0; ag=0;
      (s.allPlayers[g.homeId]||[]).forEach(p=>{});
      for(let i=0;i<Math.floor(Math.random()*4);i++){hg++;const p=randomScorer(s.allPlayers[g.homeId]);if(p){p.goals++;scorers.push({teamId:g.homeId,playerId:p.id,player:p.name,min:10+Math.floor(Math.random()*80)});}}
      for(let i=0;i<Math.floor(Math.random()*4);i++){ag++;const p=randomScorer(s.allPlayers[g.awayId]);if(p){p.goals++;scorers.push({teamId:g.awayId,playerId:p.id,player:p.name,min:10+Math.floor(Math.random()*80)});}}
    }
    g.played=true; g.homeGoals=hg; g.awayGoals=ag;
    g.events=scorers.map(x=>({min:x.min,text:`⚽ ${x.player} (${teamName(x.teamId)})`}));
    // Presença estatística: os jogadores utilizados pelos clubes da IA
    // também acumulam partidas.
    const usedH=(s.allPlayers[g.homeId]||[]).slice(0,11);
    const usedA=(s.allPlayers[g.awayId]||[]).slice(0,11);
    usedH.concat(usedA).forEach(p=>{p.matches++;});
  }
  recalcStandings(s);
}

function syncRoster(s, teamId, roster){
  s.allPlayers[teamId] = clone(roster);
  if(teamId === s.clubId) s.squad = clone(roster);
}

function marketPlayers(s){
  return GAME_TEAMS
    .filter(t=>t.id!==s.clubId)
    .flatMap(t=>(s.allPlayers[t.id]||[]).map(p=>({...p, ownerId:t.id})));
}

function processAITransfers(s){
  // Transferências automáticas: os outros clubes também podem comprar
  // jogadores do mercado, e o jogador muda de clube de verdade.
  const buyers = GAME_TEAMS.filter(t=>t.id!==s.clubId);
  if(!buyers.length) return;

  const moves = 2 + Math.floor(Math.random()*3); // 2 a 4 transferências por rodada
  for(let i=0;i<moves;i++){
    const available = marketPlayers(s).filter(p=>p.ownerId);
    if(!available.length) break;

    // Clubes mais fortes têm uma pequena preferência por jogadores melhores.
    const buyer = buyers[Math.floor(Math.random()*buyers.length)];
    const candidates = available
      .filter(p=>p.ownerId!==buyer.id)
      .sort((a,b)=>b.rating-a.rating);

    if(!candidates.length) continue;

    const top = candidates.slice(0, Math.min(18,candidates.length));
    const player = top[Math.floor(Math.random()*top.length)];
    const sellerId = player.ownerId;

    const sellerRoster = s.allPlayers[sellerId] || [];
    const idx = sellerRoster.findIndex(p=>p.id===player.id);
    if(idx<0) continue;

    // Evita que um clube fique sem opções em uma posição.
    const samePos = sellerRoster.filter(p=>p.position===player.position).length;
    if(samePos <= 1) continue;

    const bought = {...player, teamId:buyer.id};
    sellerRoster.splice(idx,1);
    const buyerRoster = s.allPlayers[buyer.id] || [];
    buyerRoster.push(bought);

    s.allPlayers[sellerId] = sellerRoster;
    s.allPlayers[buyer.id] = buyerRoster;

    if(!s.marketHistory) s.marketHistory=[];
    s.marketHistory.unshift({
      date:new Date().toLocaleDateString("pt-BR"),
      time:new Date().toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"}),
      type:"Venda",
      description:`${player.name} — ${teamName(sellerId)} → ${buyer.name}`,
      value:Math.max(50000,Math.round(player.price||0)),
      status:"Concluída"
    });
    s.marketHistory=s.marketHistory.slice(0,150);
  }
}

function advanceRound(s){
  // Antes de avançar, os outros clubes também movimentam seus elencos no mercado.
  processAITransfers(s);
  // Antes de avançar, todos os outros times também jogam a rodada.
  simulateOtherMatches(s);
  s.round++;
  const wages=Math.round(s.squad.reduce((sum,p)=>sum+p.price*.004,0));
  s.finance.balance-=wages;s.finance.expenses+=wages;
  s.finance.history.unshift({date:new Date().toLocaleDateString("pt-BR"),type:"Despesa",description:"Folha salarial",value:wages});
  completeSeasonIfNeeded(s);saveGame(s);
}
function findPlayer(s,id){return s.squad.find(p=>p.id===id)||s.market.find(p=>p.id===id);}
function globalScorers(s){
  return s.squad.map(p=>({...p,teamId:s.clubId})).concat(
    GAME_TEAMS.filter(t=>t.id!==s.clubId).flatMap(t=>s.allPlayers[t.id].map(p=>({...p,teamId:t.id})))
  ).sort((a,b)=>b.goals-a.goals);
}
document.addEventListener("DOMContentLoaded",()=>{});
