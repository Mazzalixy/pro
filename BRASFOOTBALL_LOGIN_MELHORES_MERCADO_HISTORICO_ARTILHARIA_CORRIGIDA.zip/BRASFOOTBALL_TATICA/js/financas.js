document.addEventListener("DOMContentLoaded",()=>{
 const s=loadGame();if(!s)return;renderShell("Finanças");const c=document.getElementById("pageContent");
 c.innerHTML=`<div class="page-head"><div><p class="eyebrow">ADMINISTRAÇÃO</p><h1>Finanças</h1><p>Controle do caixa e movimentações.</p></div></div>
 <div class="grid-3"><div class="stat-card"><small>Saldo atual</small><strong>${money(s.finance.balance)}</strong></div><div class="stat-card"><small>Receitas</small><strong class="positive">${money(s.finance.income)}</strong></div><div class="stat-card"><small>Despesas</small><strong class="negative">${money(s.finance.expenses)}</strong></div></div>
 <section class="panel" style="margin-top:18px"><h2>Movimentações</h2><div style="overflow:auto"><table><thead><tr><th>Data</th><th>Tipo</th><th>Descrição</th><th>Valor</th></tr></thead><tbody>${s.finance.history.slice(0,40).map(x=>`<tr><td>${x.date}</td><td>${x.type}</td><td>${x.description}</td><td class="${x.type==="Receita"||x.type==="Prêmio"?"positive":"negative"}">${x.type==="Receita"||x.type==="Prêmio"?"+":"-"} ${money(x.value)}</td></tr>`).join("")}</tbody></table></div></section>`;
});
