document.addEventListener("DOMContentLoaded",()=>{
 const s=loadGame();if(!s)return;renderShell("Jogos");const c=document.getElementById("pageContent");
 const games=[];for(const rd of s.schedule)for(const g of rd.games)if(g.homeId===s.clubId||g.awayId===s.clubId)games.push({...g,round:rd.round});
 const upcoming=games.filter(g=>!g.played).slice(0,10),played=games.filter(g=>g.played).slice(-10).reverse();
 c.innerHTML=`<div class="page-head"><div><p class="eyebrow">CALENDÁRIO</p><h1>Jogos</h1><p>Resultados e próximas partidas do seu clube.</p></div><a class="btn primary" href="partida.html">⚽ Simular próximo</a></div>
 <div class="grid-2"><section class="panel"><h2>Próximos</h2>${upcoming.map(g=>`<div class="fixture"><span>R${g.round}</span><b>${g.homeId===s.clubId?"Casa":"Fora"} • ${teamName(g.homeId===s.clubId?g.awayId:g.homeId)}</b><span>VS</span></div>`).join("")||`<div class="empty">Nenhum jogo.</div>`}</section>
 <section class="panel"><h2>Últimos resultados</h2>${played.map(g=>`<div class="fixture"><span>R${g.round}</span><b>${teamName(g.homeId)}</b><strong>${g.homeGoals} × ${g.awayGoals}</strong><b>${teamName(g.awayId)}</b></div>`).join("")||`<div class="empty">Ainda não há resultados.</div>`}</section></div>`;
});
